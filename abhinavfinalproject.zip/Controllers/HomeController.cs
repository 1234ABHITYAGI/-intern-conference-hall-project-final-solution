using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using Microsoft.EntityFrameworkCore;

namespace ConferenceRoomBooking.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Get user's bookings
            var myBookings = _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.UserId == userId.Value && b.StartTime > DateTime.Now)
                .OrderBy(b => b.StartTime)
                .Take(5)
                .ToList();

            // Get upcoming bookings for all users
            var upcomingBookings = _context.Bookings
                .Include(b => b.Room)
                .Include(b => b.User)
                .Where(b => b.StartTime > DateTime.Now)
                .OrderBy(b => b.StartTime)
                .Take(10)
                .ToList();

            ViewBag.MyBookings = myBookings;
            ViewBag.UpcomingBookings = upcomingBookings;

            return View();
        }
    }
}
