using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using System.Security.Cryptography;
using System.Text;

namespace ConferenceRoomBooking.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RegistrationController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(User model, string confirmPassword)
        {
            if (ModelState.IsValid)
            {
                // Check if username already exists
                if (_context.Users.Any(u => u.Username == model.Username))
                {
                    ModelState.AddModelError("Username", "Username already exists.");
                    return View(model);
                }

                // Check if email already exists
                if (_context.Users.Any(u => u.Email == model.Email))
                {
                    ModelState.AddModelError("Email", "Email already exists.");
                    return View(model);
                }

                // Hash password
                model.PasswordHash = HashPassword(model.PasswordHash);
                model.IsActive = true;
                model.CreatedAt = DateTime.UtcNow;
                model.UpdatedAt = DateTime.UtcNow;

                _context.Users.Add(model);
                await _context.SaveChangesAsync();

                // Assign User role
                var userRole = _context.Roles.FirstOrDefault(r => r.Name == "User");
                if (userRole != null)
                {
                    var userRoleAssignment = new UserRole
                    {
                        UserId = model.Id,
                        RoleId = userRole.Id,
                        AssignedAt = DateTime.UtcNow
                    };
                    _context.UserRoles.Add(userRoleAssignment);
                    await _context.SaveChangesAsync();
                }

                TempData["Success"] = "Registration successful. Please login.";
                return RedirectToAction("Login", "Account");
            }

            return View(model);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }
}
