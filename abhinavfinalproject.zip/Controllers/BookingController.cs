using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using Microsoft.EntityFrameworkCore;

namespace ConferenceRoomBooking.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var isAdmin = HttpContext.Session.GetString("IsAdmin") == "True";
            IQueryable<Booking> bookingsQuery = _context.Bookings.Include(b => b.User).Include(b => b.Room);

            if (!isAdmin)
            {
                bookingsQuery = bookingsQuery.Where(b => b.UserId == userId.Value);
            }

            var bookings = bookingsQuery.OrderByDescending(b => b.StartTime).ToList();
            return View(bookings);
        }

        [HttpGet]
        public IActionResult Create()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var model = new BookingViewModel();
            model.AvailableRooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Create(BookingViewModel model)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                // Check for conflicts
                var hasConflict = _context.Bookings.Any(b =>
                    b.RoomId == model.RoomId &&
                    b.Status == "Confirmed" &&
                    ((model.StartTime >= b.StartTime && model.StartTime < b.EndTime) ||
                     (model.EndTime > b.StartTime && model.EndTime <= b.EndTime) ||
                     (model.StartTime <= b.StartTime && model.EndTime >= b.EndTime)));

                if (hasConflict)
                {
                    ModelState.AddModelError("", "The selected time slot conflicts with an existing booking.");
                    model.AvailableRooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
                    return View(model);
                }

                var booking = new Booking
                {
                    UserId = userId.Value,
                    RoomId = model.RoomId,
                    Title = model.Title,
                    Description = model.Description,
                    StartTime = model.StartTime,
                    EndTime = model.EndTime,
                    Status = "Confirmed",
                    CreatedAt = DateTime.Now
                };

                _context.Bookings.Add(booking);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Booking created successfully.";
                return RedirectToAction("Index");
            }

            model.AvailableRooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
            return View(model);
        }
    }
}
