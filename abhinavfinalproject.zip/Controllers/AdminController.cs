using Microsoft.AspNetCore.Mvc;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using Microsoft.EntityFrameworkCore;

namespace ConferenceRoomBooking.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var isAdmin = HttpContext.Session.GetString("IsAdmin");
            if (isAdmin != "True")
            {
                return RedirectToAction("Login", "Account");
            }

            var stats = new
            {
                TotalUsers = _context.Users.Count(u => u.IsActive),
                TotalRooms = _context.ConferenceRooms.Count(r => r.IsActive),
                TotalBookings = _context.Bookings.Count(),
                TodayBookings = _context.Bookings.Count(b => b.StartTime.Date == DateTime.Today)
            };

            ViewBag.Stats = stats;
            
            // Get all bookings for admin view
            var allBookings = _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Room)
                .OrderByDescending(b => b.StartTime)
                .Take(20)
                .ToList();
            
            ViewBag.RecentBookings = allBookings;

            return View();
        }

        public IActionResult Rooms()
        {
            var isAdmin = HttpContext.Session.GetString("IsAdmin");
            if (isAdmin != "True")
            {
                return RedirectToAction("Login", "Account");
            }

            var rooms = _context.ConferenceRooms.Where(r => r.IsActive).ToList();
            return View(rooms);
        }

        [HttpGet]
        public IActionResult CreateRoom()
        {
            var isAdmin = HttpContext.Session.GetString("IsAdmin");
            if (isAdmin != "True")
            {
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateRoom(ConferenceRoom room)
        {
            var isAdmin = HttpContext.Session.GetString("IsAdmin");
            if (isAdmin != "True")
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                room.CreatedAt = DateTime.Now;
                room.IsActive = true;

                _context.ConferenceRooms.Add(room);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Conference room created successfully.";
                return RedirectToAction("Rooms");
            }

            return View(room);
        }
    }
}
