# 🔧 SQL Server Connection Troubleshooting

## **❌ Error Analysis:**
- **Error 53:** Server not found or not accessible
- **Named Pipes Provider Error 40:** Could not open connection
- **Network path not found:** Network connectivity issue

## **🔍 Step-by-Step Troubleshooting:**

### **Step 1: Test Basic Network Connectivity**
Open **Command Prompt** and run:
\`\`\`cmd
ping 10.7.74.186
\`\`\`

**Expected Results:**
- ✅ **Success:** You get replies (4 packets sent/received)
- ❌ **Failure:** "Request timed out" or "Destination host unreachable"

### **Step 2: Test SQL Server Port**
In **Command Prompt**, run:
\`\`\`cmd
telnet 10.7.74.186 1433
\`\`\`

**If telnet is not enabled:**
\`\`\`cmd
# Enable telnet first
dism /online /Enable-Feature /FeatureName:TelnetClient
\`\`\`

### **Step 3: Try Different Connection Methods**

#### **Method A: Specify Port Explicitly**
In SSMS connection dialog:
- **Server name:** `10.7.74.186,1433`
- **Authentication:** SQL Server Authentication
- **Login:** INTERN
- **Password:** Intern@123

#### **Method B: Try IP with Instance**
- **Server name:** `10.7.74.186\SQLEXPRESS`
- **Authentication:** SQL Server Authentication
- **Login:** INTERN
- **Password:** Intern@123

#### **Method C: Try Different Port**
- **Server name:** `10.7.74.186,1434`
- **Authentication:** SQL Server Authentication
- **Login:** INTERN
- **Password:** Intern@123

### **Step 4: Check Windows Firewall**
1. Open **Windows Defender Firewall**
2. Click **"Allow an app or feature through Windows Defender Firewall"**
3. Look for **SQL Server** entries
4. Make sure they're checked for both Private and Public networks

### **Step 5: Alternative Connection String Formats**
Try these in your application's `appsettings.json`:

\`\`\`json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=10.7.74.186,1433;Database=Test_IPI;User Id=INTERN;Password=Intern@123;TrustServerCertificate=true;Encrypt=false;"
  }
}
\`\`\`

Or:
\`\`\`json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=10.7.74.186,1433;Initial Catalog=Test_IPI;User ID=INTERN;Password=Intern@123;TrustServerCertificate=true;Encrypt=false;"
  }
}
\`\`\`
