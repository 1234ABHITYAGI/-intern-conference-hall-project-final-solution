-- Test LocalDB Connection
-- This will work with your new local database setup

-- Connect to LocalDB using SSMS:
-- Server name: (localdb)\MSSQLLocalDB
-- Authentication: Windows Authentication

-- Check if database exists
SELECT name FROM sys.databases WHERE name = 'ConferenceRoomBookingDB';

-- Use the database
USE ConferenceRoomBookingDB;
GO

-- Check tables
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE';

-- Check users
SELECT * FROM Users;

-- Check conference rooms
SELECT * FROM ConferenceRooms;

-- Check bookings
SELECT 
    b.Title,
    u.Name as UserName,
    cr.Name as RoomName,
    b.StartTime,
    b.EndTime,
    b.Status
FROM Bookings b
JOIN Users u ON b.UserId = u.Id
JOIN ConferenceRooms cr ON b.RoomId = cr.Id;
