# 🚀 Run Project Directly from GitHub

## **Step 1: Open Visual Studio 2022**
1. Click on Visual Studio 2022 icon
2. On the start screen, you'll see options
3. Click **"Clone a repository"**

## **Step 2: Clone Your Repository**
1. In the "Repository location" field, paste your GitHub URL:
   \`\`\`
   https://github.com/YourUsername/ABHINAV-INTERNSHIP-FINAL-PROJECT.git
   \`\`\`
2. Choose "Local path" (example: `C:\Projects\ConferenceRoomBooking`)
3. Click **"Clone"** button
4. Visual Studio will download everything automatically!

## **Step 3: Wait for Automatic Setup**
Visual Studio will automatically:
- ✅ Download all project files
- ✅ Restore NuGet packages
- ✅ Set up the project structure
- ✅ Open the solution

## **Step 4: Set Up Database (One Time Only)**
1. Open **SQL Server Management Studio (SSMS)**
2. Connect with these details:
   - **Server name:** `10.7.74.186`
   - **Authentication:** SQL Server Authentication
   - **Login:** `INTERN`
   - **Password:** `Intern@123`
3. Click **Connect**
4. Right-click and select **New Query**
5. Copy and paste this script:

\`\`\`sql
-- Quick Database Setup for Test_IPI
USE master;
GO

-- Create database if not exists
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'Test_IPI')
BEGIN
    CREATE DATABASE Test_IPI;
    PRINT 'Database Test_IPI created!';
END
GO

USE Test_IPI;
GO

-- Create Users table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Email NVARCHAR(255) NOT NULL UNIQUE,
        Username NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(255) NOT NULL,
        IsAdmin BIT NOT NULL DEFAULT 0,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    -- Insert sample users
    INSERT INTO Users (Name, Email, Username, Password, IsAdmin) VALUES
    ('Abhinav Tyagi', 'abhinav.tyagi@company.com', 'abhinav', 'admin123', 1),
    ('Rajesh Kumar', 'rajesh.kumar@company.com', 'rajesh', 'user123', 0),
    ('Priya Singh', 'priya.singh@company.com', 'priya', 'user123', 0);
    
    PRINT 'Users created successfully!';
END

-- Create ConferenceRooms table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ConferenceRooms')
BEGIN
    CREATE TABLE ConferenceRooms (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,
        Location NVARCHAR(200) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    -- Insert sample rooms
    INSERT INTO ConferenceRooms (Name, Description, Location) VALUES
    ('Board Room', 'Executive meeting room', 'Floor 10, East Wing'),
    ('Conference Room A', 'Large conference room', 'Floor 5, West Wing'),
    ('Meeting Room 1', 'Small meeting room', 'Floor 3, North Wing');
    
    PRINT 'Conference rooms created successfully!';
END

-- Create Bookings table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Bookings')
BEGIN
    CREATE TABLE Bookings (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL,
        ConferenceRoomId INT NOT NULL,
        Title NVARCHAR(200) NOT NULL,
        Description NVARCHAR(1000) NULL,
        StartTime DATETIME2 NOT NULL,
        EndTime DATETIME2 NOT NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Confirmed',
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        
        CONSTRAINT FK_Bookings_Users FOREIGN KEY (UserId) REFERENCES Users(Id),
        CONSTRAINT FK_Bookings_ConferenceRooms FOREIGN KEY (ConferenceRoomId) REFERENCES ConferenceRooms(Id)
    );
    
    PRINT 'Bookings table created successfully!';
END

PRINT '🎉 DATABASE SETUP COMPLETE! 🎉';
PRINT 'You can now run your application!';
\`\`\`

6. Click **Execute** (or press F5)
7. You should see success messages

## **Step 5: Run the Application**
1. Go back to **Visual Studio**
2. Press **F5** (or click the green play button)
3. The application will start automatically!
4. Your browser will open with the login page

## **Step 6: Login and Test**
Use these credentials:
- **Admin:** `abhinav` / `admin123`
- **User:** `rajesh` / `user123`

## **🎯 That's It! Your Application is Running!**
