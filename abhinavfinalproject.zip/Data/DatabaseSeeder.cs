using ConferenceRoomBooking.Models;
using System.Security.Cryptography;
using System.Text;

namespace ConferenceRoomBooking.Data
{
    public static class DatabaseSeeder
    {
        public static void SeedData(ApplicationDbContext context)
        {
            // Seed Roles
            if (!context.Roles.Any())
            {
                var roles = new[]
                {
                    new Role { Name = "Admin", Description = "System Administrator with full access", CreatedAt = DateTime.UtcNow },
                    new Role { Name = "User", Description = "Regular user with booking permissions", CreatedAt = DateTime.UtcNow }
                };

                context.Roles.AddRange(roles);
                context.SaveChanges();
            }

            // Seed Permissions
            if (!context.Permissions.Any())
            {
                var permissions = new[]
                {
                    new Permission { Name = "ManageUsers", Description = "Create, edit, and delete users", Category = "User Management", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "ManageRooms", Description = "Create, edit, and delete conference rooms", Category = "Room Management", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "ViewAllBookings", Description = "View all bookings in the system", Category = "Booking Management", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "ManageBookings", Description = "Create, edit, and cancel any booking", Category = "Booking Management", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "CreateBooking", Description = "Create new bookings", Category = "Booking", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "ViewOwnBookings", Description = "View own bookings", Category = "Booking", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "EditOwnBookings", Description = "Edit own bookings", Category = "Booking", CreatedAt = DateTime.UtcNow },
                    new Permission { Name = "CancelOwnBookings", Description = "Cancel own bookings", Category = "Booking", CreatedAt = DateTime.UtcNow }
                };

                context.Permissions.AddRange(permissions);
                context.SaveChanges();
            }

            // Seed Role Permissions
            if (!context.RolePermissions.Any())
            {
                var adminRole = context.Roles.First(r => r.Name == "Admin");
                var userRole = context.Roles.First(r => r.Name == "User");
                var allPermissions = context.Permissions.ToList();

                // Admin gets all permissions
                var adminPermissions = allPermissions.Select(p => new RolePermission
                {
                    RoleId = adminRole.Id,
                    PermissionId = p.Id,
                    GrantedAt = DateTime.UtcNow
                }).ToList();

                // User gets limited permissions
                var userPermissionNames = new[] { "CreateBooking", "ViewOwnBookings", "EditOwnBookings", "CancelOwnBookings" };
                var userPermissions = allPermissions
                    .Where(p => userPermissionNames.Contains(p.Name))
                    .Select(p => new RolePermission
                    {
                        RoleId = userRole.Id,
                        PermissionId = p.Id,
                        GrantedAt = DateTime.UtcNow
                    }).ToList();

                context.RolePermissions.AddRange(adminPermissions);
                context.RolePermissions.AddRange(userPermissions);
                context.SaveChanges();
            }

            // Seed Conference Rooms
            if (!context.ConferenceRooms.Any())
            {
                var rooms = new[]
                {
                    new ConferenceRoom
                    {
                        Name = "Board Room",
                        Location = "Floor 1, Wing A",
                        Description = "Executive boardroom with premium facilities",
                        Equipment = "Projector, Video Conferencing, Whiteboard, Premium Audio System",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new ConferenceRoom
                    {
                        Name = "Meeting Room Alpha",
                        Location = "Floor 2, Wing B",
                        Description = "Medium-sized meeting room for team discussions",
                        Equipment = "Projector, Whiteboard, Conference Phone",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new ConferenceRoom
                    {
                        Name = "Meeting Room Beta",
                        Location = "Floor 2, Wing B",
                        Description = "Comfortable meeting space with modern amenities",
                        Equipment = "Smart TV, Wireless Presentation, Whiteboard",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new ConferenceRoom
                    {
                        Name = "Training Room",
                        Location = "Floor 3, Wing C",
                        Description = "Large training room for workshops and seminars",
                        Equipment = "Projector, Sound System, Multiple Whiteboards, Flip Charts",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new ConferenceRoom
                    {
                        Name = "Conference Hall",
                        Location = "Ground Floor",
                        Description = "Large conference hall for company events",
                        Equipment = "Stage, Professional Audio/Video, Lighting System, Podium",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    }
                };

                context.ConferenceRooms.AddRange(rooms);
                context.SaveChanges();
            }

            // Seed Admin Access
            if (!context.AdminAccess.Any())
            {
                var adminAccess = new AdminAccess
                {
                    AccessCode = "ADMIN2024",
                    IsActive = true,
                    ExpiresAt = DateTime.UtcNow.AddYears(1),
                    CreatedAt = DateTime.UtcNow
                };

                context.AdminAccess.Add(adminAccess);
                context.SaveChanges();
            }

            // Seed Users
            if (!context.Users.Any())
            {
                var users = new[]
                {
                    new User
                    {
                        Username = "abhinav",
                        Email = "abhinav@company.com",
                        PasswordHash = HashPassword("admin123"),
                        FirstName = "Abhinav",
                        LastName = "Tyagi",
                        Department = "IT",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new User
                    {
                        Username = "rajesh",
                        Email = "rajesh@company.com",
                        PasswordHash = HashPassword("user123"),
                        FirstName = "Rajesh",
                        LastName = "Kumar",
                        Department = "Sales",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new User
                    {
                        Username = "priya",
                        Email = "priya@company.com",
                        PasswordHash = HashPassword("user123"),
                        FirstName = "Priya",
                        LastName = "Sharma",
                        Department = "HR",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new User
                    {
                        Username = "rohit",
                        Email = "rohit@company.com",
                        PasswordHash = HashPassword("user123"),
                        FirstName = "Rohit",
                        LastName = "Singh",
                        Department = "Marketing",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    },
                    new User
                    {
                        Username = "anita",
                        Email = "anita@company.com",
                        PasswordHash = HashPassword("user123"),
                        FirstName = "Anita",
                        LastName = "Patel",
                        Department = "Finance",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow,
                        UpdatedAt = DateTime.UtcNow
                    }
                };

                context.Users.AddRange(users);
                context.SaveChanges();

                // Assign roles to users
                var adminRole = context.Roles.First(r => r.Name == "Admin");
                var userRole = context.Roles.First(r => r.Name == "User");

                var userRoles = new[]
                {
                    new UserRole { UserId = users[0].Id, RoleId = adminRole.Id, AssignedAt = DateTime.UtcNow }, // abhinav - Admin
                    new UserRole { UserId = users[1].Id, RoleId = userRole.Id, AssignedAt = DateTime.UtcNow },  // rajesh - User
                    new UserRole { UserId = users[2].Id, RoleId = userRole.Id, AssignedAt = DateTime.UtcNow },  // priya - User
                    new UserRole { UserId = users[3].Id, RoleId = userRole.Id, AssignedAt = DateTime.UtcNow },  // rohit - User
                    new UserRole { UserId = users[4].Id, RoleId = userRole.Id, AssignedAt = DateTime.UtcNow }   // anita - User
                };

                context.UserRoles.AddRange(userRoles);
                context.SaveChanges();
            }
        }

        private static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
    }
}
