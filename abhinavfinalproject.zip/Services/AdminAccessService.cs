using Microsoft.EntityFrameworkCore;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;

namespace ConferenceRoomBooking.Services
{
    public class AdminAccessService : IAdminAccessService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AdminAccessService> _logger;
        private readonly IConfiguration _configuration;
        
        // Default admin password - should be changed in production
        private const string DEFAULT_ADMIN_PASSWORD = "AdminPanel@123";
        private const string ADMIN_PASSWORD_KEY = "ADMIN_PANEL_PASSWORD";
        private const int MAX_FAILED_ATTEMPTS = 3;
        private const int LOCKOUT_MINUTES = 15;
        private const int SESSION_TIMEOUT_MINUTES = 30;
        
        public AdminAccessService(ApplicationDbContext context, ILogger<AdminAccessService> logger, IConfiguration configuration)
        {
            _context = context;
            _logger = logger;
            _configuration = configuration;
        }
        
        public async Task<bool> ValidateAdminPasswordAsync(string password)
        {
            try
            {
                var storedPassword = await GetAdminPasswordAsync();
                return storedPassword == HashPassword(password);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error validating admin password");
                return false;
            }
        }
        
        public async Task<bool> IsAdminSessionValidAsync(int userId)
        {
            try
            {
                var sessionKey = $"AdminSession_{userId}";
                var sessionData = HttpContext.Current?.Session.GetString(sessionKey);
                
                if (string.IsNullOrEmpty(sessionData))
                    return false;
                
                var sessionParts = sessionData.Split('|');
                if (sessionParts.Length != 2)
                    return false;
                
                if (!DateTime.TryParse(sessionParts[1], out DateTime expiry))
                    return false;
                
                return DateTime.Now < expiry;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking admin session for user {UserId}", userId);
                return false;
            }
        }
        
        public async Task<bool> CreateAdminSessionAsync(int userId, string ipAddress, string userAgent)
        {
            try
            {
                var sessionExpiry = DateTime.Now.AddMinutes(SESSION_TIMEOUT_MINUTES);
                var sessionKey = $"AdminSession_{userId}";
                var sessionValue = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}|{sessionExpiry:yyyy-MM-dd HH:mm:ss}";
                
                // Store in session (you might want to use a more persistent storage)
                HttpContext.Current?.Session.SetString(sessionKey, sessionValue);
                
                // Log successful access
                var accessLog = new AdminAccessLog
                {
                    UserId = userId,
                    AccessTime = DateTime.Now,
                    IpAddress = ipAddress,
                    UserAgent = userAgent,
                    IsSuccessful = true,
                    SessionExpiry = sessionExpiry
                };
                
                _context.AdminAccessLogs.Add(accessLog);
                await _context.SaveChangesAsync();
                
                // Reset failed attempts
                await ResetFailedAttemptsAsync(userId);
                
                _logger.LogInformation("Admin session created for user {UserId} from IP {IpAddress}", userId, ipAddress);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating admin session for user {UserId}", userId);
                return false;
            }
        }
        
        public async Task<bool> RevokeAdminSessionAsync(int userId)
        {
            try
            {
                var sessionKey = $"AdminSession_{userId}";
                HttpContext.Current?.Session.Remove(sessionKey);
                
                _logger.LogInformation("Admin session revoked for user {UserId}", userId);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error revoking admin session for user {UserId}", userId);
                return false;
            }
        }
        
        public async Task<bool> IsUserLockedOutAsync(int userId)
        {
            try
            {
                var lockoutTime = await GetLockoutTimeAsync(userId);
                return lockoutTime.HasValue && DateTime.Now < lockoutTime.Value;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking lockout status for user {UserId}", userId);
                return false;
            }
        }
        
        public async Task<DateTime?> GetLockoutTimeAsync(int userId)
        {
            try
            {
                var failedAttempts = await GetFailedAttemptsCountAsync(userId);
                if (failedAttempts < MAX_FAILED_ATTEMPTS)
                    return null;
                
                var lastFailedAttempt = await _context.AdminAccessLogs
                    .Where(log => log.UserId == userId && !log.IsSuccessful)
                    .OrderByDescending(log => log.AccessTime)
                    .FirstOrDefaultAsync();
                
                if (lastFailedAttempt == null)
                    return null;
                
                return lastFailedAttempt.AccessTime.AddMinutes(LOCKOUT_MINUTES);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting lockout time for user {UserId}", userId);
                return null;
            }
        }
        
        public async Task LogFailedAttemptAsync(int userId, string ipAddress, string reason)
        {
            try
            {
                var accessLog = new AdminAccessLog
                {
                    UserId = userId,
                    AccessTime = DateTime.Now,
                    IpAddress = ipAddress,
                    UserAgent = HttpContext.Current?.Request.Headers["User-Agent"].ToString() ?? "",
                    IsSuccessful = false,
                    FailureReason = reason
                };
                
                _context.AdminAccessLogs.Add(accessLog);
                await _context.SaveChangesAsync();
                
                _logger.LogWarning("Failed admin access attempt for user {UserId} from IP {IpAddress}. Reason: {Reason}", 
                    userId, ipAddress, reason);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error logging failed attempt for user {UserId}", userId);
            }
        }
        
        public async Task<int> GetFailedAttemptsCountAsync(int userId)
        {
            try
            {
                var cutoffTime = DateTime.Now.AddMinutes(-LOCKOUT_MINUTES);
                
                return await _context.AdminAccessLogs
                    .Where(log => log.UserId == userId && 
                                 !log.IsSuccessful && 
                                 log.AccessTime > cutoffTime)
                    .CountAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting failed attempts count for user {UserId}", userId);
                return 0;
            }
        }
        
        public async Task ResetFailedAttemptsAsync(int userId)
        {
            try
            {
                // This is handled by the time-based approach in GetFailedAttemptsCountAsync
                // No need to delete records, just log the reset
                _logger.LogInformation("Failed attempts reset for user {UserId}", userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error resetting failed attempts for user {UserId}", userId);
            }
        }
        
        public async Task<bool> ChangeAdminPasswordAsync(string currentPassword, string newPassword, int changedBy)
        {
            try
            {
                if (!await ValidateAdminPasswordAsync(currentPassword))
                    return false;
                
                var hashedNewPassword = HashPassword(newPassword);
                
                var setting = await _context.AdminSettings
                    .FirstOrDefaultAsync(s => s.SettingKey == ADMIN_PASSWORD_KEY);
                
                if (setting == null)
                {
                    setting = new AdminSettings
                    {
                        SettingKey = ADMIN_PASSWORD_KEY,
                        SettingValue = hashedNewPassword,
                        Description = "Admin panel access password",
                        UpdatedBy = changedBy,
                        UpdatedAt = DateTime.Now
                    };
                    _context.AdminSettings.Add(setting);
                }
                else
                {
                    setting.SettingValue = hashedNewPassword;
                    setting.UpdatedBy = changedBy;
                    setting.UpdatedAt = DateTime.Now;
                }
                
                await _context.SaveChangesAsync();
                
                _logger.LogInformation("Admin password changed by user {UserId}", changedBy);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error changing admin password");
                return false;
            }
        }
        
        public async Task<List<AdminAccessLog>> GetRecentAccessLogsAsync(int count = 50)
        {
            try
            {
                return await _context.AdminAccessLogs
                    .Include(log => log.User)
                    .OrderByDescending(log => log.AccessTime)
                    .Take(count)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting recent access logs");
                return new List<AdminAccessLog>();
            }
        }
        
        private async Task<string> GetAdminPasswordAsync()
        {
            try
            {
                var setting = await _context.AdminSettings
                    .FirstOrDefaultAsync(s => s.SettingKey == ADMIN_PASSWORD_KEY);
                
                if (setting == null)
                {
                    // Create default password setting
                    var hashedDefaultPassword = HashPassword(DEFAULT_ADMIN_PASSWORD);
                    setting = new AdminSettings
                    {
                        SettingKey = ADMIN_PASSWORD_KEY,
                        SettingValue = hashedDefaultPassword,
                        Description = "Admin panel access password"
                    };
                    
                    _context.AdminSettings.Add(setting);
                    await _context.SaveChangesAsync();
                    
                    return hashedDefaultPassword;
                }
                
                return setting.SettingValue;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting admin password");
                return HashPassword(DEFAULT_ADMIN_PASSWORD);
            }
        }
        
        private static string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password + "AdminSalt2024"));
            return Convert.ToBase64String(hashedBytes);
        }

        public async Task<bool> ValidateAccessCodeAsync(string accessCode)
        {
            var adminAccess = await _context.AdminAccess
                .FirstOrDefaultAsync(a => a.AccessCode == accessCode && a.IsActive);

            if (adminAccess == null)
                return false;

            // Check if expired
            if (adminAccess.ExpiresAt.HasValue && adminAccess.ExpiresAt.Value < DateTime.UtcNow)
            {
                adminAccess.IsActive = false;
                await _context.SaveChangesAsync();
                return false;
            }

            // Update last used
            adminAccess.LastUsedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> ChangeAccessCodeAsync(string currentCode, string newCode)
        {
            var adminAccess = await _context.AdminAccess
                .FirstOrDefaultAsync(a => a.AccessCode == currentCode && a.IsActive);

            if (adminAccess == null)
                return false;

            adminAccess.AccessCode = newCode;
            adminAccess.LastUsedAt = DateTime.UtcNow;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> IsAccessStillValidAsync()
        {
            var activeAccess = await _context.AdminAccess
                .FirstOrDefaultAsync(a => a.IsActive);

            if (activeAccess == null)
                return false;

            if (activeAccess.ExpiresAt.HasValue && activeAccess.ExpiresAt.Value < DateTime.UtcNow)
            {
                activeAccess.IsActive = false;
                await _context.SaveChangesAsync();
                return false;
            }

            return true;
        }
    }
    
    // Helper class for HttpContext access
    public static class HttpContext
    {
        private static IHttpContextAccessor _accessor;
        
        public static Microsoft.AspNetCore.Http.HttpContext? Current => _accessor?.HttpContext;
        
        public static void Configure(IHttpContextAccessor accessor)
        {
            _accessor = accessor;
        }
    }
}
