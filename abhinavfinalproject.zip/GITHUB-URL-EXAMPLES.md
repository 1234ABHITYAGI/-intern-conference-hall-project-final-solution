# 📋 GitHub URL Examples

## **✅ Correct HTTP URLs (Use These):**

### **Format:**
\`\`\`
https://github.com/[USERNAME]/[REPOSITORY-NAME].git
\`\`\`

### **Examples:**
\`\`\`
https://github.com/AbhinavTyagi2612/ABHINAV-INTERNSHIP-FINAL-PROJECT.git
https://github.com/john123/ConferenceRoomBooking.git
https://github.com/student2024/FinalProject.git
\`\`\`

## **❌ Wrong URLs (Don't Use These):**

\`\`\`
github.com/username/repo                    ❌ Missing https://
http://github.com/username/repo.git         ❌ Should be https://
https://github.com/username/repo            ❌ Missing .git
git@github.com:username/repo.git            ❌ This is SSH format
\`\`\`

## **🔍 How to Find Your Correct URL:**

### **Step 1: Go to Your Repository**
- Open your GitHub repository in browser

### **Step 2: Click "Code" Button**
- Look for the green "Code" button
- Click it to open the dropdown

### **Step 3: Select HTTPS Tab**
- Make sure "HTTPS" tab is selected (not SSH)
- Copy the URL shown

### **Step 4: Verify Format**
- Should start with `https://github.com/`
- Should end with `.git`

## **📋 Quick Checklist:**
- ✅ Starts with `https://`
- ✅ Contains your username
- ✅ Contains repository name
- ✅ Ends with `.git`
- ✅ No spaces or special characters

## **🎯 Ready to Clone!**
Once you have the correct HTTPS URL, paste it into Visual Studio's clone dialog and you're good to go!
