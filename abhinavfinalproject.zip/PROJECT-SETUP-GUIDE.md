# Project Setup Guide

## **Method 1: Download from GitHub (Recommended)**

### If you have the GitHub repository:
\`\`\`bash
# Open Command Prompt or PowerShell
cd C:\
mkdir Projects
cd Projects
git clone [YOUR_GITHUB_REPOSITORY_URL]
cd [PROJECT_FOLDER_NAME]
\`\`\`

## **Method 2: Create New Project from Scratch**

### Step 1: Create New Project in Visual Studio
1. Open Visual Studio 2022
2. Click "Create a new project"
3. Search for "ASP.NET Core Web App (Model-View-Controller)"
4. Click Next
5. **Project name:** ConferenceRoomBooking
6. **Location:** C:\Projects\ConferenceRoomBooking
7. Click Next
8. **Framework:** .NET 6.0 or .NET 7.0
9. **Authentication:** None
10. ✅ Configure for HTTPS
11. Click Create

### Step 2: Install Required NuGet Packages
Right-click on project → Manage NuGet Packages → Browse tab

Install these packages:
\`\`\`xml
Microsoft.EntityFrameworkCore.SqlServer (Version 6.0.0 or higher)
Microsoft.EntityFrameworkCore.Tools (Version 6.0.0 or higher)
Microsoft.EntityFrameworkCore.Design (Version 6.0.0 or higher)
Microsoft.AspNetCore.Session (Version 2.2.0 or higher)
\`\`\`

### Step 3: Copy Project Files
Copy all the code files from the provided project structure into your new project.
