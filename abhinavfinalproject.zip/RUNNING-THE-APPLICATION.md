# Running the Application

## **Step 1: Build the Project**

### In Visual Studio:
1. Open the project
2. Press **Ctrl+Shift+B** to build
3. Check Output window for any errors
4. Resolve any missing NuGet packages

### Command Line:
\`\`\`bash
cd C:\Projects\ConferenceRoomBooking
dotnet build
\`\`\`

## **Step 2: Run the Application**

### In Visual Studio:
1. Press **F5** to run with debugging
2. Or press **Ctrl+F5** to run without debugging
3. Browser will open automatically

### Command Line:
\`\`\`bash
dotnet run
\`\`\`

## **Step 3: Test the Application**

### Login Credentials:
- **Admin:** abhinav / admin123
- **Users:** rajesh / user123, rohit / user123, priya / user123

### Test Features:
1. ✅ Login with admin credentials
2. ✅ Create a new booking
3. ✅ View calendar
4. ✅ Access admin panel (admin only)
5. ✅ Manage conference rooms (admin only)

## **Step 4: Troubleshooting**

### Common Issues:

#### Database Connection Error:
- Check if SQL Server is accessible
- Verify connection string in appsettings.json
- Test connection using SSMS first

#### Build Errors:
- Restore NuGet packages: Right-click solution → Restore NuGet Packages
- Clean and rebuild: Build → Clean Solution, then Build → Rebuild Solution

#### Port Already in Use:
- Change port in launchSettings.json
- Or stop other applications using the same port
