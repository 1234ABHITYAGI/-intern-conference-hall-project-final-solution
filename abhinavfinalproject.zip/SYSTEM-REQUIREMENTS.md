# System Requirements for Conference Room Booking Application

## **Required Software Installation**

### 1. **Visual Studio 2022 Community (FREE)**
- **Download:** https://visualstudio.microsoft.com/vs/community/
- **Version:** Visual Studio 2022 Community Edition
- **Workloads to Install:**
  - ✅ ASP.NET and web development
  - ✅ .NET desktop development
  - ✅ Data storage and processing

### 2. **SQL Server Management Studio (SSMS) - FREE**
- **Download:** https://docs.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms
- **Purpose:** To manage and query the SQL Server database
- **Version:** Latest version (19.x or higher)

### 3. **Git for Windows (Optional but Recommended)**
- **Download:** https://git-scm.com/download/win
- **Purpose:** Version control and cloning repositories

## **System Specifications**
- **OS:** Windows 10/11 (64-bit)
- **RAM:** Minimum 8GB, Recommended 16GB
- **Storage:** At least 10GB free space
- **Processor:** Intel i5 or AMD equivalent

## **Network Requirements**
- Internet connection for downloading packages
- Access to SQL Server: 10.7.74.186
- Port 1433 should be accessible for SQL Server connection
