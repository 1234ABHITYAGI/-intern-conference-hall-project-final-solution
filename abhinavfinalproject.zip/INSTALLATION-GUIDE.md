# Complete Installation Guide

## **Step 1: Install Visual Studio 2022**

### Download and Install:
1. Go to: https://visualstudio.microsoft.com/vs/community/
2. Download Visual Studio 2022 Community (FREE)
3. Run the installer
4. Select these workloads:
   - ✅ **ASP.NET and web development**
   - ✅ **.NET desktop development** 
   - ✅ **Data storage and processing**

### Important Components:
- .NET 6.0 or .NET 7.0 SDK
- IIS Express
- SQL Server Express LocalDB
- Web Deploy
- Git for Windows (if not already installed)

## **Step 2: Install SQL Server Management Studio**

1. Download from: https://aka.ms/ssmsfullsetup
2. Install with default settings
3. This will help you manage the SQL Server database

## **Step 3: Verify .NET Installation**

Open Command Prompt and run:
\`\`\`bash
dotnet --version
\`\`\`
Should show .NET 6.0 or higher

## **Step 4: Test SQL Server Connection**

1. Open SQL Server Management Studio
2. Connect with these details:
   - **Server:** 10.7.74.186
   - **Authentication:** SQL Server Authentication
   - **Login:** INTERN
   - **Password:** Intern@123
3. Verify you can see the Test_IPI database
