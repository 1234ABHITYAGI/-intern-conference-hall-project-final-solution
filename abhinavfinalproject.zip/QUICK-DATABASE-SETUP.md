# ⚡ Quick Database Setup (2 Minutes)

## **Open SSMS and Connect:**
1. Open **SQL Server Management Studio**
2. **Server name:** `10.7.74.186`
3. **Authentication:** SQL Server Authentication
4. **Login:** `INTERN`
5. **Password:** `Intern@123`
6. Click **Connect**

## **Run This One Script:**
Copy this entire script and run it in SSMS:

\`\`\`sql
-- Complete Database Setup in One Script
USE master;
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'Test_IPI')
    CREATE DATABASE Test_IPI;
GO

USE Test_IPI;
GO

-- Users Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Email NVARCHAR(255) NOT NULL UNIQUE,
        Username NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(255) NOT NULL,
        IsAdmin BIT NOT NULL DEFAULT 0,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    INSERT INTO Users (Name, Email, Username, Password, IsAdmin) VALUES
    ('Abhinav Tyagi', 'abhinav.tyagi@company.com', 'abhinav', 'admin123', 1),
    ('Rajesh Kumar', 'rajesh.kumar@company.com', 'rajesh', 'user123', 0),
    ('Priya Singh', 'priya.singh@company.com', 'priya', 'user123', 0),
    ('Rohit Gupta', 'rohit.gupta@company.com', 'rohit', 'user123', 0);
END

-- Conference Rooms Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ConferenceRooms')
BEGIN
    CREATE TABLE ConferenceRooms (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,
        Location NVARCHAR(200) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    
    INSERT INTO ConferenceRooms (Name, Description, Location) VALUES
    ('Board Room', 'Executive meeting room with video conferencing', 'Floor 10, East Wing'),
    ('Conference Room A', 'Large conference room with presentation equipment', 'Floor 5, West Wing'),
    ('Conference Room B', 'Medium conference room with whiteboard', 'Floor 5, East Wing'),
    ('Meeting Room 1', 'Small meeting room for team discussions', 'Floor 3, North Wing'),
    ('Training Room', 'Large training room with projector', 'Floor 2, Central');
END

-- Bookings Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Bookings')
BEGIN
    CREATE TABLE Bookings (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL,
        ConferenceRoomId INT NOT NULL,
        Title NVARCHAR(200) NOT NULL,
        Description NVARCHAR(1000) NULL,
        StartTime DATETIME2 NOT NULL,
        EndTime DATETIME2 NOT NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Confirmed',
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        
        CONSTRAINT FK_Bookings_Users FOREIGN KEY (UserId) REFERENCES Users(Id),
        CONSTRAINT FK_Bookings_ConferenceRooms FOREIGN KEY (ConferenceRoomId) REFERENCES ConferenceRooms(Id)
    );
END

PRINT '🎉 DATABASE SETUP COMPLETE! 🎉';
PRINT 'Login Credentials:';
PRINT 'Admin: abhinav / admin123';
PRINT 'Users: rajesh, priya, rohit / user123';
\`\`\`

## **✅ Done! Database is Ready!**
