using Microsoft.EntityFrameworkCore;
using ConferenceRoomBooking.Data;
using ConferenceRoomBooking.Models;
using ConferenceRoomBooking.Services;
using ConferenceRoomBooking.Middleware;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Security.Cryptography;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add Entity Framework
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add session support
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Add custom services
builder.Services.AddScoped<IPermissionService, PermissionService>();
builder.Services.AddScoped<IAdminAccessService, AdminAccessService>();
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

// Configure HttpContext accessor
var httpContextAccessor = app.Services.GetRequiredService<IHttpContextAccessor>();
ConferenceRoomBooking.Services.HttpContext.Configure(httpContextAccessor);

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Add session middleware
app.UseSession();

// Add custom middleware
app.UseMiddleware<AdminAccessMiddleware>();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

// Create database and seed data
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    try
    {
        context.Database.EnsureCreated();
        SeedDatabase(context);
    }
    catch (Exception ex)
    {
        var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
        logger.LogError(ex, "An error occurred while creating the database.");
    }
}

app.Run();

static void SeedDatabase(ApplicationDbContext context)
{
    // Add users if none exist
    if (!context.Users.Any())
    {
        var users = new[]
        {
            new User 
            { 
                Name = "Abhinav Tyagi", 
                Email = "abhinav.tyagi@company.com", 
                Username = "abhinav", 
                Password = HashPassword("admin123"), 
                IsAdmin = true,
                IsActive = true,
                CreatedAt = DateTime.Now
            },
            new User 
            { 
                Name = "Rajesh Kumar", 
                Email = "rajesh.kumar@company.com", 
                Username = "rajesh", 
                Password = HashPassword("user123"), 
                IsAdmin = false,
                IsActive = true,
                CreatedAt = DateTime.Now
            },
            new User 
            { 
                Name = "Priya Singh", 
                Email = "priya.singh@company.com", 
                Username = "priya", 
                Password = HashPassword("user123"), 
                IsAdmin = false,
                IsActive = true,
                CreatedAt = DateTime.Now
            },
            new User 
            { 
                Name = "Rohit Gupta", 
                Email = "rohit.gupta@company.com", 
                Username = "rohit", 
                Password = HashPassword("user123"), 
                IsAdmin = false,
                IsActive = true,
                CreatedAt = DateTime.Now
            }
        };
        
        context.Users.AddRange(users);
        context.SaveChanges();
    }
    
    // Add conference rooms if none exist
    if (!context.ConferenceRooms.Any())
    {
        var rooms = new[]
        {
            new ConferenceRoom 
            { 
                Name = "Board Room", 
                Description = "Executive meeting room with video conferencing facilities", 
                Location = "10th Floor, Tower A",
                IsActive = true,
                CreatedAt = DateTime.Now
            },
            new ConferenceRoom 
            { 
                Name = "Conference Room A", 
                Description = "Large conference room with presentation equipment", 
                Location = "5th Floor, Tower B",
                IsActive = true,
                CreatedAt = DateTime.Now
            },
            new ConferenceRoom 
            { 
                Name = "Meeting Room 1", 
                Description = "Small meeting room for team discussions", 
                Location = "3rd Floor, Tower A",
                IsActive = true,
                CreatedAt = DateTime.Now
            },
            new ConferenceRoom 
            { 
                Name = "Training Room", 
                Description = "Training room with modern AV equipment", 
                Location = "2nd Floor, Training Wing",
                IsActive = true,
                CreatedAt = DateTime.Now
            }
        };
        
        context.ConferenceRooms.AddRange(rooms);
        context.SaveChanges();
    }
}

static string HashPassword(string password)
{
    using (var sha256 = SHA256.Create())
    {
        var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(hashedBytes);
    }
}
