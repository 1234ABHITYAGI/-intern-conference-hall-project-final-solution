# 📋 Visual Studio Clone Steps (With Screenshots Guide)

## **Method 1: From Visual Studio Start Screen**

### **When you open Visual Studio 2022:**
1. You'll see the start screen with options
2. Look for **"Clone a repository"** option
3. Click on it

### **In the Clone Repository dialog:**
1. **Repository location:** Paste your GitHub URL
2. **Local path:** Choose where to save (like `C:\Projects\ConferenceRoomBooking`)
3. Click **"Clone"**

## **Method 2: If Visual Studio is Already Open**

### **From the menu:**
1. Go to **File** → **Clone Repository**
2. Or go to **Git** → **Clone Repository**
3. Enter your GitHub URL
4. Choose local folder
5. Click **Clone**

## **Method 3: Using Team Explorer**
1. In Visual Studio, go to **View** → **Team Explorer**
2. Click **"Clone"** under Local Git Repositories
3. Enter your GitHub URL
4. Click **Clone**

## **What Your GitHub URL Should Look Like:**
\`\`\`
https://github.com/AbhinavTyagi2612/ABHINAV-INTERNSHIP-FINAL-PROJECT.git
\`\`\`
(Replace with your actual GitHub username and repository name)

## **After Cloning:**
- Visual Studio will automatically open your project
- All files will be downloaded
- NuGet packages will be restored
- Project will be ready to run!
