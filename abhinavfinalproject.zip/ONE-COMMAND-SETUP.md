# One-Command Setup Guide

## **🚀 Super Quick Setup (After GitHub Upload)**

### **Single PowerShell Command:**
```powershell
# Open PowerShell as Administrator and run:
cd C:\; mkdir Projects; cd Projects; git clone [YOUR_GITHUB_URL]; cd ConferenceRoomBooking; start ConferenceRoomBooking.sln
