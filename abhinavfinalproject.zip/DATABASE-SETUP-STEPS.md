# Database Setup Steps

## **Step 1: Test Database Connection**

### Using SQL Server Management Studio:
1. Open SSMS
2. Connect to server: **10.7.74.186**
3. Login: **INTERN**
4. Password: **Intern@123**
5. Check if **Test_IPI** database exists

### Using Visual Studio:
1. Open Visual Studio
2. Go to View → SQL Server Object Explorer
3. Add SQL Server → Server name: 10.7.74.186
4. Authentication: SQL Server Authentication
5. User: INTERN, Password: Intern@123

## **Step 2: Run Database Setup Scripts**

### In SQL Server Management Studio:
1. Connect to the server
2. Open New Query
3. Copy and paste the content from: `scripts/complete-database-setup.sql`
4. Execute the script (F5)

### Expected Output:
\`\`\`
✅ DATABASE SETUP COMPLETE FOR Test_IPI!
✅ Users: 6 active users
✅ Rooms: 6 available rooms
✅ Bookings: Sample bookings created
\`\`\`

## **Step 3: Verify Setup**
Run the verification script: `scripts/final-verification.sql`

## **Step 4: Update Connection String**
Make sure appsettings.json has:
\`\`\`json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=10.7.74.186;Database=Test_IPI;User Id=INTERN;Password=Intern@123;TrustServerCertificate=true;MultipleActiveResultSets=true;"
  }
}
