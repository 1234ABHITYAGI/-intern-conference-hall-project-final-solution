# Quick Start Commands

## **For Command Line Users**

### Step 1: Open Command Prompt as Administrator
\`\`\`bash
# Press Windows + R, type "cmd", press Ctrl+Shift+Enter
\`\`\`

### Step 2: Navigate and Create Project Folder
\`\`\`bash
# Go to C: drive
cd C:\

# Create Projects folder
mkdir Projects
cd Projects

# If you have the project files, extract them here
# Or create new project folder
mkdir ConferenceRoomBooking
cd ConferenceRoomBooking
\`\`\`

### Step 3: Open in Visual Studio
\`\`\`bash
# If you have the .sln file
start ConferenceRoomBooking.sln

# Or open Visual Studio and open the project folder
\`\`\`

## **For Visual Studio Users**

### Method 1: Open Existing Project
1. Open Visual Studio 2022
2. Click "Open a project or solution"
3. Navigate to your project folder
4. Select ConferenceRoomBooking.sln
5. Click Open

### Method 2: Create New Project
1. Open Visual Studio 2022
2. Click "Create a new project"
3. Follow the Project Setup Guide steps
