namespace ConferenceRoomBooking.Models
{
    public static class PermissionConstants
    {
        // Booking Permissions
        public const string VIEW_ALL_BOOKINGS = "VIEW_ALL_BOOKINGS";
        public const string CREATE_BOOKING = "CREATE_BOOKING";
        public const string EDIT_OWN_BOOKING = "EDIT_OWN_BOOKING";
        public const string EDIT_ANY_BOOKING = "EDIT_ANY_BOOKING";
        public const string CANCEL_OWN_BOOKING = "CANCEL_OWN_BOOKING";
        public const string CANCEL_ANY_BOOKING = "CANCEL_ANY_BOOKING";
        public const string DELETE_ANY_BOOKING = "DELETE_ANY_BOOKING";
        public const string BOOK_ON_BEHALF = "BOOK_ON_BEHALF";
        
        // Room Permissions
        public const string VIEW_ROOMS = "VIEW_ROOMS";
        public const string MANAGE_ROOMS = "MANAGE_ROOMS";
        public const string CREATE_ROOM = "CREATE_ROOM";
        public const string EDIT_ROOM = "EDIT_ROOM";
        public const string DELETE_ROOM = "DELETE_ROOM";
        
        // User Management Permissions
        public const string VIEW_USERS = "VIEW_USERS";
        public const string MANAGE_USERS = "MANAGE_USERS";
        public const string CREATE_USER = "CREATE_USER";
        public const string EDIT_USER = "EDIT_USER";
        public const string DELETE_USER = "DELETE_USER";
        public const string ASSIGN_ROLES = "ASSIGN_ROLES";
        
        // System Permissions
        public const string ACCESS_ADMIN_PANEL = "ACCESS_ADMIN_PANEL";
        public const string VIEW_REPORTS = "VIEW_REPORTS";
        public const string MANAGE_SYSTEM_SETTINGS = "MANAGE_SYSTEM_SETTINGS";
        public const string VIEW_AUDIT_LOGS = "VIEW_AUDIT_LOGS";
        
        // Updated Permissions
        public const string ManageUsers = "ManageUsers";
        public const string ManageRooms = "ManageRooms";
        public const string ViewAllBookings = "ViewAllBookings";
        public const string ManageBookings = "ManageBookings";
        public const string CreateBooking = "CreateBooking";
        public const string ViewOwnBookings = "ViewOwnBookings";
        public const string EditOwnBookings = "EditOwnBookings";
        public const string CancelOwnBookings = "CancelOwnBookings";
    }
    
    public static class RoleConstants
    {
        public const string SUPER_ADMIN = "Super Admin";
        public const string ADMIN = "Admin";
        public const string MANAGER = "Manager";
        public const string USER = "User";
        public const string GUEST = "Guest";
    }
}
