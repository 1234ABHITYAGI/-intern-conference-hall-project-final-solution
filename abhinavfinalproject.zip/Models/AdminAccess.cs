using System.ComponentModel.DataAnnotations;

namespace ConferenceRoomBooking.Models
{
    public class AdminAccess
    {
        public int Id { get; set; }

        [Required]
        [StringLength(255)]
        public string AccessCode { get; set; } = string.Empty;

        public bool IsActive { get; set; } = true;

        public DateTime? ExpiresAt { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? LastUsedAt { get; set; }
    }
}
