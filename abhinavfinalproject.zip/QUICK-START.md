# Quick Start Guide

## For Developers (Local Setup)

### 1. Install Prerequisites
- ✅ Visual Studio 2022 Community (Free)
- ✅ SQL Server Express (Free) 
- ✅ SQL Server Management Studio (Free)

### 2. Get the Code
\`\`\`bash
git clone https://github.com/AbhinavTyagi2612/ABHINAV-INTERNSHIP-FINAL-PROJECT.git
cd ABHINAV-INTERNSHIP-FINAL-PROJECT
