# Troubleshooting Guide

## **Common Issues and Solutions**

### 1. **Visual Studio Installation Issues**
**Problem:** Visual Studio won't install or missing workloads
**Solution:**
- Run Visual Studio Installer as Administrator
- Repair the installation
- Ensure you have enough disk space (10GB+)
- Download offline installer if internet is slow

### 2. **Database Connection Issues**
**Problem:** Cannot connect to SQL Server 10.7.74.186
**Solutions:**
- Check network connectivity: `ping 10.7.74.186`
- Verify SQL Server allows remote connections
- Check Windows Firewall settings
- Test with SQL Server Management Studio first
- Verify INTERN user has proper permissions

### 3. **Build Errors**
**Problem:** Project won't build
**Solutions:**
\`\`\`bash
# Restore NuGet packages
dotnet restore

# Clean and rebuild
dotnet clean
dotnet build
\`\`\`

### 4. **Missing NuGet Packages**
**Problem:** Package references not found
**Solution:**
- Right-click solution → Restore NuGet Packages
- Or use Package Manager Console:
\`\`\`bash
Update-Package -reinstall
\`\`\`

### 5. **Port Already in Use**
**Problem:** Application won't start due to port conflict
**Solution:**
- Change port in `Properties/launchSettings.json`
- Or kill process using the port:
\`\`\`bash
netstat -ano | findstr :5000
taskkill /PID [PID_NUMBER] /F
\`\`\`

### 6. **Database Tables Not Created**
**Problem:** Tables don't exist in Test_IPI database
**Solution:**
- Run `scripts/complete-database-setup.sql` in SSMS
- Check INTERN user has CREATE TABLE permissions
- Verify you're connected to Test_IPI database

## **Getting Help**
- Check Output window in Visual Studio for detailed errors
- Use SQL Server Management Studio to test database operations
- Enable detailed logging in appsettings.json
