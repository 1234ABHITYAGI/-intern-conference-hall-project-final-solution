# 🔧 Troubleshooting Clone Issues

## **Issue 1: Can't Find "Clone Repository" Option**
**Solution:**
- Make sure you have Visual Studio 2022 (not older versions)
- Look for "Get code from an online repository"
- Or go to File → Clone Repository

## **Issue 2: GitHub URL Not Working**
**Check your URL format:**
- ✅ Correct: `https://github.com/username/repository.git`
- ❌ Wrong: `github.com/username/repository`
- ❌ Wrong: `https://github.com/username/repository` (missing .git)

## **Issue 3: "Repository Not Found" Error**
**Solutions:**
- Make sure your repository is **public** on GitHub
- Check if the repository name is correct
- Try downloading ZIP instead: GitHub → Code → Download ZIP

## **Issue 4: Visual Studio Won't Open Project**
**Solutions:**
- Look for `.sln` file in the cloned folder
- Double-click the `.sln` file
- Or in Visual Studio: File → Open → Project/Solution

## **Issue 5: Database Connection Error**
**Check:**
- SSMS can connect to 10.7.74.186
- Username: INTERN, Password: Intern@123
- Database Test_IPI exists
- Run the database setup script

## **Issue 6: Build Errors**
**Solutions:**
- Right-click solution → Restore NuGet Packages
- Build → Clean Solution
- Build → Rebuild Solution

## **🆘 Emergency Method (If Clone Fails):**
1. Go to your GitHub repository in browser
2. Click **Code** → **Download ZIP**
3. Extract the ZIP file
4. Open the `.sln` file in Visual Studio
