# 🔄 Alternative Database Setup Options

## **Option 1: Use Local SQL Server Express**

If the remote server is not accessible, you can set up locally:

### **Install SQL Server Express (FREE):**
1. Download: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
2. Choose **"Express"** edition
3. Install with default settings

### **Update Connection String:**
\`\`\`json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\MSSQLLocalDB;Database=ConferenceRoomBooking;Trusted_Connection=true;MultipleActiveResultSets=true;"
  }
}
\`\`\`

## **Option 2: Use SQLite (Simplest)**

### **Install SQLite NuGet Package:**
\`\`\`bash
Install-Package Microsoft.EntityFrameworkCore.Sqlite
\`\`\`

### **Update Connection String:**
\`\`\`json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=ConferenceRoomBooking.db"
  }
}
\`\`\`

### **Update Program.cs:**
\`\`\`csharp
// Change from:
options.UseSqlServer(connectionString)

// To:
options.UseSqlite(connectionString)
\`\`\`

## **Option 3: Contact Network Administrator**

The server `10.7.74.186` might be:
- Behind a firewall
- Requiring VPN connection
- Temporarily down
- Requiring specific network configuration

**Contact your IT department or network administrator for:**
- VPN access requirements
- Firewall exceptions
- Correct server address and port
- Network connectivity troubleshooting
