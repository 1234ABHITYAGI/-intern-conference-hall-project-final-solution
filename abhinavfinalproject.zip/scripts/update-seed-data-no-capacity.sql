-- Update seed data to remove capacity references
USE TestIPI;
GO

-- Update existing conference rooms to remove any capacity-related descriptions
UPDATE ConferenceRooms SET 
    Description = 'Executive meeting room with video conferencing facilities'
WHERE Name = 'Board Room';

UPDATE ConferenceRooms SET 
    Description = 'Large conference room with presentation equipment'
WHERE Name = 'Conference Room A';

UPDATE ConferenceRooms SET 
    Description = 'Medium conference room with whiteboard'
WHERE Name = 'Conference Room B';

UPDATE ConferenceRooms SET 
    Description = 'Small meeting room for team discussions'
WHERE Name = 'Meeting Room 1';

UPDATE ConferenceRooms SET 
    Description = 'Small meeting room with phone conference'
WHERE Name = 'Meeting Room 2';

UPDATE ConferenceRooms SET 
    Description = 'Large training room with projector and sound system'
WHERE Name = 'Training Room';

UPDATE ConferenceRooms SET 
    Description = 'Creative space with flexible seating arrangements'
WHERE Name = 'Innovation Lab';

UPDATE ConferenceRooms SET 
    Description = 'Professional meeting room for client presentations'
WHERE Name = 'Client Meeting Room';

PRINT 'Conference room descriptions updated (capacity references removed)!';

-- Show updated rooms
SELECT 
    Id,
    Name,
    Description,
    Location,
    CASE WHEN IsActive = 1 THEN 'Active' ELSE 'Inactive' END as Status
FROM ConferenceRooms
ORDER BY Name;
