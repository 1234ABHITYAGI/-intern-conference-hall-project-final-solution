-- Step 6: Verification Queries to Test Database
USE ConferenceRoomBookingDb;
GO

-- Check if all tables exist
SELECT 
    TABLE_NAME,
    TABLE_TYPE
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;

-- Check Users table
SELECT 'Users' AS TableName, COUNT(*) AS RecordCount FROM Users
UNION ALL
SELECT 'ConferenceRooms', COUNT(*) FROM ConferenceRooms
UNION ALL
SELECT 'Bookings', COUNT(*) FROM Bookings;

-- View all users
SELECT Id, Name, Email, Username, IsAdmin, CreatedAt FROM Users;

-- View all conference rooms
SELECT Id, Name, Description, Capacity, Location, IsActive FROM ConferenceRooms;

-- View all bookings with details
SELECT 
    b.Id,
    b.Title,
    u.Name AS UserName,
    cr.Name AS RoomName,
    b.StartTime,
    b.EndTime,
    b.Status
FROM Bookings b
INNER JOIN Users u ON b.UserId = u.Id
INNER JOIN ConferenceRooms cr ON b.ConferenceRoomId = cr.Id
ORDER BY b.StartTime;

-- Test room availability procedure
EXEC sp_CheckRoomAvailability 
    @RoomId = 1, 
    @StartTime = '2024-01-15 10:00:00', 
    @EndTime = '2024-01-15 11:00:00';

-- Test user booking statistics
EXEC sp_GetUserBookingStats @UserId = 2;

-- View active bookings
SELECT * FROM vw_ActiveBookings;

-- View room utilization
SELECT * FROM vw_RoomUtilization;

PRINT 'Database verification completed!';
