-- Update Abhinav Sharma to Abhinav Tyagi
USE TestIPI;
GO

-- Update user name and email for Abhinav
UPDATE Users 
SET Name = 'Abhinav Tyagi',
    Email = 'abhinav.tyagi@company.com'
WHERE Username = 'abhinav';

-- Verify the change
SELECT 
    Id,
    Name,
    Email,
    Username,
    CASE WHEN IsAdmin = 1 THEN 'Yes' ELSE 'No' END as IsAdmin,
    CreatedAt
FROM Users 
WHERE Username = 'abhinav';

PRINT 'Abhinav Sharma updated to Abhinav Tyagi successfully!';

-- Show all users to confirm
SELECT 
    Name,
    Username,
    Email,
    CASE WHEN IsAdmin = 1 THEN 'Admin' ELSE 'User' END as Role
FROM Users 
WHERE IsActive = 1
ORDER BY Name;
