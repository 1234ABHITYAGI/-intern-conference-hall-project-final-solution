-- COMPLETE DATABASE SETUP FOR CONFERENCE ROOM BOOKING SYSTEM
-- Server: 10.7.74.186
-- Database: Test_IPI
-- User: INTERN

USE master;
GO

-- Step 1: Create Database if it doesn't exist
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'Test_IPI')
BEGIN
    CREATE DATABASE Test_IPI;
    PRINT 'Database Test_IPI created successfully!';
END
ELSE
BEGIN
    PRINT 'Database Test_IPI already exists.';
END
GO

USE Test_IPI;
GO

-- Step 2: Create Tables
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
BEGIN
    CREATE TABLE Users (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Email NVARCHAR(255) NOT NULL UNIQUE,
        Username NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(255) NOT NULL,
        IsAdmin BIT NOT NULL DEFAULT 0,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        LastLoginAt DATETIME2 NULL
    );
    PRINT 'Users table created.';
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ConferenceRooms')
BEGIN
    CREATE TABLE ConferenceRooms (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,
        Location NVARCHAR(200) NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE()
    );
    PRINT 'ConferenceRooms table created.';
END

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Bookings')
BEGIN
    CREATE TABLE Bookings (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL,
        ConferenceRoomId INT NOT NULL,
        Title NVARCHAR(200) NOT NULL,
        Description NVARCHAR(1000) NULL,
        StartTime DATETIME2 NOT NULL,
        EndTime DATETIME2 NOT NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Confirmed',
        CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
        CancelledAt DATETIME2 NULL,
        
        CONSTRAINT FK_Bookings_Users FOREIGN KEY (UserId) REFERENCES Users(Id),
        CONSTRAINT FK_Bookings_ConferenceRooms FOREIGN KEY (ConferenceRoomId) REFERENCES ConferenceRooms(Id)
    );
    PRINT 'Bookings table created.';
END

-- Step 3: Create Indexes
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_Username')
    CREATE INDEX IX_Users_Username ON Users(Username);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_Email')
    CREATE INDEX IX_Users_Email ON Users(Email);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Bookings_UserId')
    CREATE INDEX IX_Bookings_UserId ON Bookings(UserId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Bookings_ConferenceRoomId')
    CREATE INDEX IX_Bookings_ConferenceRoomId ON Bookings(ConferenceRoomId);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Bookings_StartTime')
    CREATE INDEX IX_Bookings_StartTime ON Bookings(StartTime);

-- Step 4: Insert Users (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM Users)
BEGIN
    INSERT INTO Users (Name, Email, Username, Password, IsAdmin) VALUES
    ('Abhinav Tyagi', 'abhinav.tyagi@company.com', 'abhinav', 'admin123', 1),
    ('Rajesh Kumar', 'rajesh.kumar@company.com', 'rajesh', 'user123', 0),
    ('Rohit Gupta', 'rohit.gupta@company.com', 'rohit', 'user123', 0),
    ('Priya Singh', 'priya.singh@company.com', 'priya', 'user123', 0),
    ('Vikram Patel', 'vikram.patel@company.com', 'vikram', 'user123', 0),
    ('Anita Verma', 'anita.verma@company.com', 'anita', 'user123', 0);
    PRINT 'Sample users inserted.';
END

-- Step 5: Insert Conference Rooms (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM ConferenceRooms)
BEGIN
    INSERT INTO ConferenceRooms (Name, Description, Location) VALUES
    ('Board Room', 'Executive meeting room with video conferencing facilities', 'Floor 10, East Wing'),
    ('Conference Room A', 'Large conference room with presentation equipment', 'Floor 5, West Wing'),
    ('Conference Room B', 'Medium conference room with whiteboard', 'Floor 5, East Wing'),
    ('Meeting Room 1', 'Small meeting room for team discussions', 'Floor 3, North Wing'),
    ('Meeting Room 2', 'Small meeting room with phone conference', 'Floor 3, South Wing'),
    ('Training Room', 'Large training room with projector and sound system', 'Floor 2, Central');
    PRINT 'Sample conference rooms inserted.';
END

-- Step 6: Insert Sample Bookings (only if table is empty)
IF NOT EXISTS (SELECT 1 FROM Bookings)
BEGIN
    DECLARE @Tomorrow DATETIME2 = DATEADD(DAY, 1, CAST(GETDATE() AS DATE));

    INSERT INTO Bookings (UserId, ConferenceRoomId, Title, Description, StartTime, EndTime, Status) VALUES
    (2, 1, 'Team Meeting', 'Weekly team sync', DATEADD(HOUR, 9, @Tomorrow), DATEADD(HOUR, 10, @Tomorrow), 'Confirmed'),
    (3, 2, 'Client Presentation', 'Product demo', DATEADD(HOUR, 14, @Tomorrow), DATEADD(HOUR, 16, @Tomorrow), 'Confirmed'),
    (4, 3, 'Project Planning', 'Sprint planning', DATEADD(HOUR, 11, @Tomorrow), DATEADD(HOUR, 12, @Tomorrow), 'Confirmed');
    PRINT 'Sample bookings inserted.';
END

PRINT '';
PRINT '✅ DATABASE SETUP COMPLETE FOR Test_IPI!';
PRINT '';
PRINT 'CONNECTION DETAILS:';
PRINT 'Server: 10.7.74.186';
PRINT 'Database: Test_IPI';
PRINT 'User: INTERN';
PRINT '';
PRINT 'LOGIN CREDENTIALS:';
PRINT 'Admin: abhinav / admin123';
PRINT 'Users: rajesh, rohit, priya / user123';
PRINT '';
PRINT 'CONFERENCE ROOMS: 6 rooms created';
PRINT 'SAMPLE BOOKINGS: 3 bookings created';
