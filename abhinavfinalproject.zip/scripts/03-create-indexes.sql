-- Step 3: Create Indexes for Better Performance
USE ConferenceRoomBookingDb;
GO

-- Index on Users table
CREATE NONCLUSTERED INDEX IX_Users_Username ON Users(Username);
CREATE NONCLUSTERED INDEX IX_Users_Email ON Users(Email);
CREATE NONCLUSTERED INDEX IX_Users_IsAdmin ON Users(IsAdmin);
GO

-- Index on ConferenceRooms table
CREATE NONCLUSTERED INDEX IX_ConferenceRooms_IsActive ON ConferenceRooms(IsActive);
CREATE NONCLUSTERED INDEX IX_ConferenceRooms_Name ON ConferenceRooms(Name);
GO

-- Index on Bookings table (most important for performance)
CREATE NONCLUSTERED INDEX IX_Bookings_UserId ON Bookings(UserId);
CREATE NONCLUSTERED INDEX IX_Bookings_ConferenceRoomId ON Bookings(ConferenceRoomId);
CREATE NONCLUSTERED INDEX IX_Bookings_StartTime ON Bookings(StartTime);
CREATE NONCLUSTERED INDEX IX_Bookings_EndTime ON Bookings(EndTime);
CREATE NONCLUSTERED INDEX IX_Bookings_Status ON Bookings(Status);

-- Composite index for conflict checking (very important!)
CREATE NONCLUSTERED INDEX IX_Bookings_RoomTime_Status 
ON Bookings(ConferenceRoomId, StartTime, EndTime, Status);

-- Composite index for user bookings
CREATE NONCLUSTERED INDEX IX_Bookings_User_Status_Time 
ON Bookings(UserId, Status, StartTime);
GO

PRINT 'All indexes created successfully!';
