-- Quick connection test for Test_IPI database
-- Server: 10.7.74.186
-- User: INTERN
-- Password: Intern@123
-- Database: Test_IPI

-- Step 1: Test connection to server
SELECT 
    @@SERVERNAME as ServerName,
    @@VERSION as SQLServerVersion,
    GETDATE() as CurrentDateTime;

-- Step 2: Check if Test_IPI database exists
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'Test_IPI')
BEGIN
    PRINT '✅ Database Test_IPI found!';
    
    -- Switch to Test_IPI database
    USE Test_IPI;
    
    -- Step 3: Check user permissions
    SELECT 
        'INTERN' as LoginUser,
        USER_NAME() as DatabaseUser,
        IS_MEMBER('db_owner') as IsDbOwner,
        IS_MEMBER('db_datareader') as CanRead,
        IS_MEMBER('db_datawriter') as CanWrite;
    
    -- Step 4: Check existing tables
    PRINT '';
    PRINT 'EXISTING TABLES IN Test_IPI:';
    SELECT 
        '   ' + TABLE_NAME as TableName
    FROM INFORMATION_SCHEMA.TABLES 
    WHERE TABLE_TYPE = 'BASE TABLE'
    ORDER BY TABLE_NAME;
    
    -- Step 5: Test basic operations
    PRINT '';
    PRINT 'TESTING BASIC OPERATIONS:';
    
    -- Test SELECT permission
    BEGIN TRY
        IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Users')
        BEGIN
            SELECT COUNT(*) as UserCount FROM Users;
            PRINT '✅ Can read from Users table';
        END
        ELSE
        BEGIN
            PRINT '⚠️ Users table does not exist yet';
        END
    END TRY
    BEGIN CATCH
        PRINT '❌ Cannot read from Users table: ' + ERROR_MESSAGE();
    END CATCH
    
    -- Test CREATE permission
    BEGIN TRY
        CREATE TABLE TestTable_INTERN (
            Id INT IDENTITY(1,1) PRIMARY KEY,
            TestMessage NVARCHAR(100),
            CreatedAt DATETIME2 DEFAULT GETDATE()
        );
        
        INSERT INTO TestTable_INTERN (TestMessage) VALUES ('Test successful on Test_IPI!');
        SELECT * FROM TestTable_INTERN;
        DROP TABLE TestTable_INTERN;
        
        PRINT '✅ Can create, insert, and drop tables';
    END TRY
    BEGIN CATCH
        PRINT '❌ Cannot perform table operations: ' + ERROR_MESSAGE();
    END CATCH
    
END
ELSE
BEGIN
    PRINT '❌ Database Test_IPI not found!';
    PRINT 'Available databases:';
    SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb');
END

PRINT '';
PRINT 'CONNECTION TEST COMPLETED FOR Test_IPI DATABASE';
