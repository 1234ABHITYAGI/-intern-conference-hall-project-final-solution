-- Update roles: Only Abhinav Tyagi as Admin, everyone else as User
USE TestIPI;
GO

-- Clear all existing role assignments
DELETE FROM UserRoles;

-- Update Abhinav Sharma to Abhinav Tyagi
UPDATE Users 
SET Name = 'Abhinav Tyagi',
    Email = 'abhinav.tyagi@company.com',
    IsAdmin = 1  -- Keep legacy admin flag for Abhinav
WHERE Username = 'abhinav';

-- Make sure all other users are NOT admin
UPDATE Users 
SET IsAdmin = 0
WHERE Username != 'abhinav';

-- Assign roles: Only Abhinav as Admin, everyone else as User
-- Make Abhinav Tyagi the ONLY Admin
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Username = 'abhinav' AND r.Name = 'Admin';

-- Make ALL other users regular Users (including Rajesh)
INSERT INTO UserRoles (UserId, RoleId, AssignedAt, IsActive)
SELECT u.Id, r.Id, GETDATE(), 1
FROM Users u
CROSS JOIN Roles r
WHERE u.Username != 'abhinav' AND r.Name = 'User';

PRINT 'Roles updated successfully!';
PRINT 'ONLY Abhinav Tyagi is Admin now.';
PRINT 'All other users (including Rajesh) are regular Users.';

-- Verification
SELECT 
    u.Name,
    u.Username,
    u.Email,
    CASE WHEN u.IsAdmin = 1 THEN 'ADMIN' ELSE 'USER' END as SystemRole,
    STRING_AGG(r.Name, ', ') as AssignedRoles
FROM Users u
LEFT JOIN UserRoles ur ON u.Id = ur.UserId AND ur.IsActive = 1
LEFT JOIN Roles r ON ur.RoleId = r.Id
WHERE u.IsActive = 1
GROUP BY u.Id, u.Name, u.Username, u.Email, u.IsAdmin
ORDER BY u.IsAdmin DESC, u.Name;
