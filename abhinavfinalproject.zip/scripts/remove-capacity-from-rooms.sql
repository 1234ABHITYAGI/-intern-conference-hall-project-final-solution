-- Remove capacity column from ConferenceRooms table
USE TestIPI;
GO

-- Step 1: Check current table structure
PRINT 'Current ConferenceRooms table structure:';
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'ConferenceRooms'
ORDER BY ORDINAL_POSITION;

PRINT '';
PRINT 'Removing Capacity column from ConferenceRooms table...';

-- Step 2: Drop the capacity column
ALTER TABLE ConferenceRooms 
DROP COLUMN Capacity;

PRINT 'Capacity column removed successfully!';
PRINT '';

-- Step 3: Verify the change
PRINT 'Updated ConferenceRooms table structure:';
SELECT 
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'ConferenceRooms'
ORDER BY ORDINAL_POSITION;

PRINT '';

-- Step 4: Show current room data without capacity
PRINT 'Current conference rooms (without capacity):';
SELECT 
    Id,
    Name,
    Description,
    Location,
    CASE WHEN IsActive = 1 THEN 'Active' ELSE 'Inactive' END as Status,
    CreatedAt
FROM ConferenceRooms
ORDER BY Name;

PRINT '';
PRINT '✅ Capacity field successfully removed from all conference rooms!';
