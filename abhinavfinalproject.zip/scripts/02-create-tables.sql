-- Step 2: Create Tables with Proper Relationships
USE ConferenceRoomBookingDb;
GO

-- Create Users Table
CREATE TABLE Users (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) NOT NULL UNIQUE,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    IsAdmin BIT NOT NULL DEFAULT 0,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    -- Constraints
    CONSTRAINT CK_Users_Email CHECK (Email LIKE '%@%.%'),
    CONSTRAINT CK_Users_Name CHECK (LEN(TRIM(Name)) > 0),
    CONSTRAINT CK_Users_Username CHECK (LEN(TRIM(Username)) >= 3)
);
GO

-- Create ConferenceRooms Table
CREATE TABLE ConferenceRooms (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL,
    Capacity INT NOT NULL,
    Location NVARCHAR(200) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    
    -- Constraints
    CONSTRAINT CK_ConferenceRooms_Name CHECK (LEN(TRIM(Name)) > 0),
    CONSTRAINT CK_ConferenceRooms_Capacity CHECK (Capacity > 0 AND Capacity <= 100)
);
GO

-- Create Bookings Table
CREATE TABLE Bookings (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NOT NULL,
    ConferenceRoomId INT NOT NULL,
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000) NULL,
    StartTime DATETIME2 NOT NULL,
    EndTime DATETIME2 NOT NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Confirmed',
    CreatedAt DATETIME2 NOT NULL DEFAULT GETDATE(),
    CancelledAt DATETIME2 NULL,
    
    -- Foreign Key Constraints
    CONSTRAINT FK_Bookings_Users FOREIGN KEY (UserId) 
        REFERENCES Users(Id) ON DELETE CASCADE,
    CONSTRAINT FK_Bookings_ConferenceRooms FOREIGN KEY (ConferenceRoomId) 
        REFERENCES ConferenceRooms(Id) ON DELETE CASCADE,
    
    -- Check Constraints
    CONSTRAINT CK_Bookings_Title CHECK (LEN(TRIM(Title)) > 0),
    CONSTRAINT CK_Bookings_DateTime CHECK (EndTime > StartTime),
    CONSTRAINT CK_Bookings_Status CHECK (Status IN ('Confirmed', 'Cancelled', 'Completed')),
    CONSTRAINT CK_Bookings_FutureDate CHECK (StartTime >= CAST(GETDATE() AS DATE))
);
GO

PRINT 'All tables created successfully!';
